<template>
    <div class="container">
        <div class="loading" v-show="loading">
            <div class="spinner-border text-primary spinner-center" role="status">
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <div class="text-center h3 mb-3">
                    Đăng nhập
                </div>
                <form @submit.prevent="login">
                                <div class="form-floating mb-3">     
                                 <input class="form-control" id="user" placeholder="Nhập tài khoản" v-model="user.username" required>
                                 <label for="user">Tài khoản</label>
                              
                               </div>
                               <div class="form-floating mb-3">
                                 <input class="form-control" id="pass" name="pass" type="password" placeholder="Nhập mật khẩu" 
                                  v-model="user.password" required>
                                 <label>Mật khẩu</label>
                               </div>
                               <div class="form-check-inline check mb-3">
                                 <label class="form-check-label">
                                   <input  type="checkbox" class="form-check-input" value="Ok" name="accept" id="accept" checked="checked"> Chấp nhận <a href="/dieu-khoan">Điều khoản sử dụng</a>
                                 </label>
                               </div>
                               
                               <div class="form-group mb-3">
                                 <button class="btn btn-success font-weight-bold form-control" type="submit" >
                                   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
                                       <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                                       <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                                     </svg> ĐĂNG NHẬP
                                   </button>
                               </div>
                               <div class="alert alert-danger w-50 m-1" role="alert" align="left" v-if="loginFail">
                                Thông tin tài khoản hoặc mật khẩu không chính xác
                              </div>
                               
                       </form>
            </div>
        </div>
    </div>
</template>
<style scoped>
.check{
  float: left;
}
.loading {
    background: rgba(0, 0, 0, .5);
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
}

.spinner-center {
    top: 50%;
    left: 50%;
    position: absolute;
}
</style>
<script>
import axios from 'axios';
export default{
    name: 'LoginPage',
    data(){
        return{
            user :{
                username : '',
                password : '',
                password_confirm : ''
            },validate :{
                username : {
                    lengthError : false,
                    invalidError : false,
                    existError : false,
                    maxLength : 0
                },
                password : {
                    lengthError : false,
                    invalidError : false
                },
                password_confirm : {
                    lengthError : false,
                    invalidError : false,
                    matchError : false
                },

            },loading:false ,
            loginFail : false
        }
    },
    methods: {
        login(){
            this.loading = true;
            this.loginFail = false;
            axios.post('/account/login?username='+this.user.username + "&password="+this.user.password).then(res => {
                if(res.data.code == 200){
                    if(res.data.data.isAdmin == true){
                        this.$router.push('/admin/manager/login-page');
                    }
                    localStorage.setItem('token', res.data.token);
                    localStorage.setItem('user', JSON.stringify(res.data.data));
                     setTimeout(async() => {
                        this.loading = false;
                    }, 1000);
                    setTimeout(async() => {
                        this.loginSuccess = true;
                    }, 1000);
                    console.log('tholv',res.data.data.isAdmin);
                    if(res.data.data.isAdmin){
                        this.$router.push('/admin/user-manager');
                    }else {
                        this.$router.push('/home').then(() => {
                        this.$router.go();
                    });
                    }
                    
                }else{
                    this.loginFail = true;
                    setTimeout(async() => {
                        this.loading = false;
                    }, 1000);
                    return;
                }
            }).catch(err => {
                setTimeout(() => {
                        this.loading = false;
                    }, 1000);
                console.log(err);
            })
        }
    }
}
</script>