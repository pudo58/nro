<template>
    <div class="container">
      <div class="row">
        <div class="col-5 text-center h2">
          Quản lý Account
        </div>
      </div>
      <hr>
      <div class="row data">
        <div class="col-8"></div>
        <div class="col-4">
          <div class="input-group mb-4">
            <input type="text" class="form-control-sm" placeholder="Search" v-model="searchKeyWork" aria-label="Recipient's username" aria-describedby="button-addon2" @click.prevent="search" @change.prevent="search" 
            @input.prevent="search">
            <button v-bind:title="'Thêm mới'" type="button" class="btn btn-sm btn-success m-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
  </svg>    
          </button>
          <button v-bind:title="'Xóa'" type="button" class="btn btn-sm btn-danger m-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
    <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
  </svg>
          </button>
          </div>
        </div>
      </div>
        <div class="fetch-data table-responsive">
          <table class="table table-striped table-hover">
              <thead>
                  <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Tài khoản</th>
                      <th scope="col">Mật khẩu</th>
                      <th scope="col">Thỏi vàng</th>
                      <th scope="col">Thành viên GOD</th>
                      <th scope="col">Là admin</th>
                      <th scope="col">Action</th>       
                  </tr>
              </thead>
              <tbody>
                  <tr v-for="item in listUser" :key="item.id">
                     <td>
                        {{item.id}}
                     </td>
                        <td>
                            {{item.username}}
                        </td>
                        <td>
                            {{item.password}}
                        </td>
                        <td>
                            {{item.thoiVang}}
                        </td>
                        <td>
                            {{item.active == 1 ? 'Có' : 'Không'}}
                        </td>
                        <td>
                            {{item.isAdmin == 1 ? 'Có' : 'Không'}}
                        </td>
                        
                      <td>
                          <button class="btn btn-success " type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" @click.prevent="getObjectItem(item)">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z"/>
  </svg>
                          </button>
                         
                          <button onclick="alert('đang phát triển')"  type="button " class="btn btn-danger"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
    <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
  </svg></button>
                      </td>
                  </tr>
              </tbody>
          </table>
        </div>
      <div class="row">
        <div class="col-1">
          Show
        </div>
        <div class="col-1">
          <select  aria-label="Default select example" v-model="size" @change="fetchData">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="50">30</option>
            <option value="100">40</option>
          </select>
        </div>
        <div class="col-1">
          entries
        </div>
        <div class="col-6"></div>
        <nav aria-label="Page navigation example" class="col-3">
    <ul class="pagination">
      <li class="page-item"><a class="page-link" @click.prevent="page=page - 1 <=0 ? 0 :page - 1;fetchData()">Previous</a></li>
      <!-- <li class="page-item" ><a class="page-link" ></a></li> next page -->
      <li class="page-item"><a class="page-link" href="#" @click.prevent="page=page + 1 >= size ? size :page + 1;fetchData()">Next</a></li>
    </ul>
  </nav>
      </div>
       
      </div>
  <div class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- 

 -->
 <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form @submit.prevent="update">
                <div class="form-floating mb-2">
                    <input class="form-control"  type="text" disabled
                     v-model="getObject.username">
                    <label>Tài khoản</label>
                </div>
                <div class="form-floating mb-2">
                    <input class="form-control"  type="text" 
                     v-model="getObject.password">
                    <label>Mật khẩu</label>
                </div>
                <div class="form-floating mb-2">
                    <input class="form-control"  type="text"
                     v-model="getObject.thoiVang">
                    <label>Thỏi vàng</label>
                </div>
                <div class="form-floating mb-2">
                    <input class="form-control"  type="text"
                     v-model="getObject.thoiVang">
                    <label>Thỏi vàng</label>
                </div>
                <div class="form-floating mb-2">
                   <select name="" id="" class="form-select" v-model="getObject.active">
                         <option value="1">Có</option>
                         <option value="0">Không</option>
                   </select>
                    <label>Là thành viên Blue</label>
                </div>
                <div class="form-floating mb-2">
                    <select name="" id="" class="form-select" v-model="getObject.isAdmin">
                          <option value="1">Có</option>
                          <option value="0">Không</option>
                    </select>
                     <label>Là admin</label>
                 </div>
               <div class="e" style="display: flex;">
                <button type="submit" class="btn btn-outline-success m-1" >Cập nhật</button>
                <button type="button" class="btn btn-outline-danger m-1 close" data-bs-dismiss="modal" >Đóng</button>
               </div>
            </form>
        </div>
      </div>
    </div>
  </div>
  </template>
  <style scoped>
  i:hover{
      cursor: pointer;
      color: red;
  }
  .data{
    padding: 0;
    margin: 0;
  }
  nav ul{
    padding-bottom: calc(10px + 10px);
    float : right;
  }
  ul a{
    cursor: pointer;;
  }
  </style>
  <script>
  import axios from 'axios';
  export default {
    name: "UserManager",
    data(){
        return {
            page : 0 ,
            size : 10,
            listUser : [],
            token : localStorage.getItem('token'),
            searchKeyWork : '',
            getObject : {

            }
        }
    },created(){
        this.fetchData();
    }
    ,methods: {
        fetchData(){   
            axios.get('/account/page/' + this.page + '/' + this.size +"?token="+this.token).then(res =>{
                this.listUser = res.data.content;
            })
        },search(){
            if(this.searchKeyWork == '' || this.searchKeyWork== null){
                this.fetchData();
            }
            axios.get('/account/find/equals/' + this.searchKeyWork).then(res =>{
                this.listUser = res.data;
                console.log('tholv',res.data)
            });
        },getObjectItem(item){
           this.getObject = item;
        },update(){
            axios.put('/account/update/'+ this.getObject.id,this.getObject).then(res =>{
                res;
                this.fetchData();

            })
        },deleteUser(id){
            axios.delete('/account/delete/' + id).then(res =>{
                res;
                this.fetchData();
            })
        },
    
    },
  }
  </script>