<template>
    <div class="container forum">
        <div class="post-admin">
            <div class="list">
                <img src="../../assets/images/god.png" alt="" align="left" width="25">
                <a @click.prevent="this.$router.push('/account/update/god')" class="text-left d-flex p-1 h4 text-decoration-none text-dark"><b>Nâng cấp tài khoản lên GOD và nạp thỏi vàng
                    <img src="../../assets/images/new.gif" alt="">
                </b></a>
            </div>
        </div>
    </div>
</template>
<style>
    .forum{
        background-color: #e7bcac;
    }
    .list:hover{
        cursor: pointer;
        color : red ;
        text-decoration: underline;
    }
</style>