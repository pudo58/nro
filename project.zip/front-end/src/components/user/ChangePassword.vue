<template>
    <div class="container">
        <div class="row">
            <div class="col-3">

            </div>
            <div class="col-6">
                <p class="text-center h3">Đổi mật khẩu</p>
                <form @submit.prevent="changePassword">
                    <div class="form-floating mb-3">
                        <input class="form-control" id="pass" name="pass" type="password" placeholder="Nhập mật khẩu" 
                         v-model="password">
                        <label>Mật khẩu mới</label>
                        <small  v-show="validate.password.lengthError">Mật khẩu phải lớn hơn 8 ký tự <br> </small>
                        <small v-show="validate.password.invalidError">Mật khẩu phải bao gồm ký tự và ít nhất 1 chữ số <br> </small>
                      </div>
                      <div class="form-floating mb-3">
                          <input class="form-control" id="pass" name="pass" type="password" placeholder="Nhập mật khẩu" 
                           v-model="password_confirm">
                          <label>Nhập lại mật khẩu</label>
                          <small v-show="validate.password_confirm.lengthError">Mật khẩu nhập lại phải lớn hơn 8 ký tự <br> </small>
                          <small v-show="validate.password_confirm.invalidError">Mật khẩu không hợp lệ <br> </small>
                          <small v-show="validate.password_confirm.matchError">Mật khẩu không khớp <br> </small>
                      </div>
                      <div class="form-group">
                        <button class="btn btn-success font-weight-bold form-control" type="submit" >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                              <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                            </svg> ĐỔI MẬT KHẨU
                          </button>
                          <div class="alert alert-success w-50 m-1" role="alert" align="left" v-show="success">
                            Đổi mật khẩu thành công
                          </div>
                          <div class="alert alert-danger w-50 m-1" role="alert" align="left" v-show="error">
                            Bạn chưa đăng nhập
                          </div>
                      </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios';
    export default {
        name: 'ChangePassword',
        data() {
            return {
                password: '',
                password_confirm: '',
                validate: {
                    password: {
                        lengthError: false,
                        invalidError: false
                    },
                    password_confirm: {
                        lengthError: false,
                        invalidError: false,
                        matchError: false
                    }
                },success : false,
                error : false
            }
        },
        methods: {
            changePassword(){
                this.validate.password.lengthError = false ;
                this.validate.password.invalidError = false ;
                this.validate.password_confirm.lengthError = false ;
                this.validate.password_confirm.invalidError = false ;
                this.validate.password_confirm.matchError = false ;
                var token = localStorage.getItem('token');
                this.validate.password.lengthError = this.password.length == 0 || this.password.length < 8;
                this.validate.password.invalidError =!this.password.match(/^[a-zA-Z0-9]+$/)
                this.validate.password_confirm.lengthError = this.password_confirm.length == 0 || this.password_confirm.length < 8;
                this.validate.password_confirm.invalidError =!this.password_confirm.match(/^[a-zA-Z0-9]+$/)
                this.validate.password_confirm.matchError = !this.validate.password_confirm.invalidError && this.password != this.password_confirm;
                if(!this.validate.password.lengthError && !this.validate.password.invalidError && !this.validate.password_confirm.lengthError && !this.validate.password_confirm.invalidError && !this.validate.password_confirm.matchError){
                    this.loading = true;
                    axios.post('/account/change-password?token=' + token + "&password="+this.password).then(res => {
                        setTimeout(async() => {
                            this.loading = false;
                        }, 1000);
                        alert("Đổi mật khẩu thành công");
                        this.$router.push('/');
                        res;
                        
                    }).catch(err => {
                        err;
                        setTimeout(async() => {
                            this.loading = false;
                        }, 1000);
                        this.error = true;
                    })
                }
            },
        }
    }
</script>
<style>
form small{
    text-align: left;
    color  : red;
    display: flex;
}
</style>