<template>
    <div class="container pt-1 color-main2" v-show="showActionBasic">
        <div class="row mb-3">
            <div class="col text-center">
                <a class="btn btn-sm border btn-danger text-light" @click.prevent="this.$router.push('/login')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                      </svg> ĐĂNG NHẬP
                    </a>
                <a class="btn btn-sm mr-2 border btn-danger text-light" @click.prevent="this.$router.push('/register')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 0 16 16">
                        <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                        <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
                    </svg>ĐĂNG KÝ
                </a>
            </div>
        </div>
    </div>
    <div class="container" v-if="showAction">
        <div class="col text-center">
            <a class="btn btn-sm mr-2 border btn-danger text-light" @click.prevent="this.$router.push('/account/profile')">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
                  </svg>
                Tên tài khoản : {{user.username}}
            </a>
            <a class="btn btn-sm mr-2 border btn-danger text-light" @click="this.$router.push('/change-password')">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key-fill" viewBox="0 0 16 16">
                    <path d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
                  </svg>
                   Đổi mật khẩu
                </a>
            <a class="btn btn-sm mr-2 border btn-danger text-light" @click.prevent="logout">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0v2z"/>
                    <path fill-rule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z"/>
                  </svg> Đăng xuất
                </a>
        </div>
    </div>
    <div class="container color-main2 pb-2" id="pageHeader">
        <!-- 
        <div class="row pb-2">
          <div class="col">
            <a href="box/3" class="btn btn-sm bg-info text-white"><img src="/image/new.gif"> Báo lỗi mất vật phẩm ngày 06/05 <img src="/image/new.gif"></a>
          </div>
        </div>
      -->
        <div class="row text-center bg-danger menu">
                <div class="col border">
                        <a class="btn btn-sm" @click.prevent="this.$router.push('/forum-page')">Diễn đàn</a>
                    </div>
                <div class="col border">
                        <a href="#" class="btn btn-sm ">Góp ý</a>
                    </div>
                <div class="col border bg-light error">
                        <a href="#" class="btn btn-sm">Báo lỗi</a>
                    </div>
            </div>
      </div>

</template>
<script>
import axios from 'axios';
export default{
    name: 'ButtonHeader',
    data : function(){
        return{
            token : localStorage.getItem('token'),
            showAction : false,
            showActionBasic : false,
            user : JSON.parse(localStorage.getItem('user'))
        }
    },
    created(){
        this.showActionUser();
    }
    ,methods: {
        showActionUser(){
            axios.get("/token/find/"+ this.token).then(async res=>{
                if(res.data.code == 200){
                    this.showAction = true;
                    this.showActionBasic = false;
                }
            }).catch(err=>{
                err;
                this.showAction = false;
                this.showActionBasic = true;
            })
            // this.showAction = this.token != null;
            this.showActionBasic = this.user == null;
        },
        logout(){
            axios.post("/account/logout?token=" + this.token).then(res=>{
                res;
                localStorage.removeItem('token');
                localStorage.removeItem('user');
                this.showAction = false;
                this.showActionBasic = true;
            }).catch(err=>{
                err;
            })

        }
    }
}
</script>
<style>
.error:hover{
    border: 1px solid red;
    color : red
}
</style>