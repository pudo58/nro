<template lang="">
    <div class="container">
        <div class="col text-centter">
            <div class="text-center" style="display: block;">
              <img src="../../assets/images/gender0.png" style="width: 48px; "><br>
              <div style="font-size: 13px; padding-top: 5px">
                Tài khoản : <b>{{user.account.username}}</b>
            </div>
                    </div>
                    Thỏi vàng : <b class="text-danger">{{user.account.thoiVang}}</b>
            <div class="text-center mt-3">
              <a class="btn  btn-outline-danger" style="padding: 2px 4px;" @click.prevent="this.$router.push('/account/update/god')">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cash-coin" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0z"/>
                    <path d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1h-.003zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195l.054.012z"/>
                    <path d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083c.058-.344.145-.678.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1H1z"/>
                    <path d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 5.982 5.982 0 0 1 3.13-1.567z"/>
                  </svg> Nạp vàng</a>
              <a class="btn btn-outline-danger" style="padding: 2px 4px;" @click.prevent="showHistory=!showHistory;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-history" viewBox="0 0 16 16">
                    <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022l-.074.997zm2.004.45a7.003 7.003 0 0 0-.985-.299l.219-.976c.383.086.76.2 1.126.342l-.36.933zm1.37.71a7.01 7.01 0 0 0-.439-.27l.493-.87a8.025 8.025 0 0 1 .979.654l-.615.789a6.996 6.996 0 0 0-.418-.302zm1.834 1.79a6.99 6.99 0 0 0-.653-.796l.724-.69c.27.285.52.59.747.91l-.818.576zm.744 1.352a7.08 7.08 0 0 0-.214-.468l.893-.45a7.976 7.976 0 0 1 .45 1.088l-.95.313a7.023 7.023 0 0 0-.179-.483zm.53 2.507a6.991 6.991 0 0 0-.1-1.025l.985-.17c.067.386.106.778.116 1.17l-1 .025zm-.131 1.538c.033-.17.06-.339.081-.51l.993.123a7.957 7.957 0 0 1-.23 1.155l-.964-.267c.046-.165.086-.332.12-.501zm-.952 2.379c.184-.29.346-.594.486-.908l.914.405c-.16.36-.345.706-.555 1.038l-.845-.535zm-.964 1.205c.122-.122.239-.248.35-.378l.758.653a8.073 8.073 0 0 1-.401.432l-.707-.707z"/>
                    <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0v1z"/>
                    <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5z"/>
                  </svg> Lịch sử nạp thẻ</a>
            </div>
          </div>
          <div class="table table-responsive" v-if="showHistory">
            <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Thời gian</th>
                  <th>Số tiền</th>
                  <th>Loại thẻ</th>
                  <th>Seri</th>
                  <th>Mã thẻ</th>
                  <th>Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in history" :key="index">
                  <td>{{index + 1}}</td>
                  <td>{{convertDate(item.created)}}</td>
                  <td>{{formatPrice(item.cardDetail.price)}}</td>
                  <td>{{item.cardDetail.card.name}}</td>
                  <td>{{item.seri}}</td>
                  <td>{{item.code}}</td>
                  <td style="cursor:pointer;color:red;" class="text-light" :class="[{'bg-danger':item.status==0},{'bg-success':item.status==1}]">{{item.status == 0 ? 'Chưa duyệt':'Đã duyệt'}}</td>
                </tr>
              </tbody>
            </table>
          </div>
    </div>
</template>
<script>
import axios from 'axios';

export default{
    name : 'ProfileUser',
    data : function(){
        return{
            user : [],
            history : [],
            token : localStorage.getItem('token'),
            showHistory : false,
        }
    },created(){
        this.getHistory();
        this.getUser();
    },methods:{
        getUser(){
          axios.get("/token/find/"+ this.token).then(res => {
            this.user = res.data.data;
            localStorage.setItem('user', JSON.stringify(res.data));
          });
        },
        getHistory(){
            axios.get('/recharge-card/history/' + this.token).then(res => {
                this.history = res.data;
                console.log(this.history);
            })
        },convertDate(date){
          Date.prototype.customFormat = function(formatString){
            var YYYY,YY,MMMM,MMM,MM,M,DDDD,DDD,DD,D,hhhh,hhh,hh,h,mm,m,ss,s,ampm,AMPM,dMod,th;
            YY = ((YYYY=this.getFullYear())+"").slice(-2);
            MM = (M=this.getMonth()+1)<10?('0'+M):M;
            MMM = (MMMM=["January","February","March","April","May","June","July","August","September","October","November","December"][M-1]).substring(0,3);
            DD = (D=this.getDate())<10?('0'+D):D;
            DDD = (DDDD=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][this.getDay()]).substring(0,3);
            th=(D>=10&&D<=20)?'th':((dMod=D%10)==1)?'st':(dMod==2)?'nd':(dMod==3)?'rd':'th';
            formatString = formatString.replace("#YYYY#",YYYY).replace("#YY#",YY).replace("#MMMM#",MMMM).replace("#MMM#",MMM).replace("#MM#",MM).replace("#M#",M).replace("#DDDD#",DDDD).replace("#DDD#",DDD).replace("#DD#",DD).replace("#D#",D).replace("#th#",th);
            h=(hhh=this.getHours());
            if (h==0) h=24;
            if (h>12) h-=12;
            hh = h<10?('0'+h):h;
            hhhh = hhh<10?('0'+hhh):hhh;
            AMPM=(ampm=hhh<12?'am':'pm').toUpperCase();
            mm=(m=this.getMinutes())<10?('0'+m):m;
            ss=(s=this.getSeconds())<10?('0'+s):s;
            return formatString.replace("#hhhh#",hhhh).replace("#hhh#",hhh).replace("#hh#",hh).replace("#h#",h).replace("#mm#",mm).replace("#m#",m).replace("#ss#",ss).replace("#s#",s).replace("#ampm#",ampm).replace("#AMPM#",AMPM);
          };
          var d = new Date(date);
          return d.customFormat( "#DD#/#MM#/#YYYY# #hh#:#mm#:#ss#" )
        },
        formatPrice(value) {
          let val = (value/1).toFixed(2).replace('.',',')
          return (val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")).substring(0,val.indexOf(",")+1);
        }
    }
}
</script>