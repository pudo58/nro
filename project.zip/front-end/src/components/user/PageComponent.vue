<template>
    <div class="container">
        <HeaderComponentVue>
            <template v-slot:button-header>
                <ButtonHeaderVue></ButtonHeaderVue>
            </template>
        </HeaderComponentVue>
        <router-view></router-view>
        <br>
        <br>
        <FooterComponentVue></FooterComponentVue>
    </div>
</template>
<script>
import HeaderComponentVue from '../user/HeaderComponent.vue';
import FooterComponentVue from '../user/FooterComponent.vue';
import ButtonHeaderVue from './ButtonHeader.vue';
export default{
    name: 'PageComponent',
    components: {
        HeaderComponentVue,
        FooterComponentVue,
        ButtonHeaderVue
    }
}
</script>
<style scoped>
</style>