<template>
    <div class="container">
      <div class="row">
        <div class="col-3">
        </div>
        <div class="col-6">
            <p class="text-center h3 md-3">Đăng ký</p>
          <form @submit.prevent="createUser">
              <div class="form-floating mb-3">     
                <input class="form-control" id="user" placeholder="Nhập tài khoản" v-model="user.username">
                <label for="user">Tài khoản</label>
                <small v-show="validate.username.lengthError">Tài khoản không được để trống<br></small>
                <small v-show="validate.username.existError">Tài khoản đã tồn tại <br> </small>
                <small v-show="validate.username.invalidError">Tài khoản không hợp lệ<br> </small>
                <small v-show="validate.username.maxLength">Tài khoản phải trên 8 ký tự<br> </small>
              </div>
              <div class="form-floating mb-3">
                <input class="form-control" id="pass" name="pass" type="password" placeholder="Nhập mật khẩu" 
                 v-model="user.password">
                <label>Mật khẩu</label>
                <small  v-if="validate.password.lengthError">Mật khẩu không được để trống<br> </small>
                <small v-if="validate.password.invalidError">Mật khẩu không hợp lệ<br> </small>
              </div>
              <div class="form-floating mb-3">
                  <input class="form-control" id="pass" name="pass" type="password" placeholder="Nhập mật khẩu" 
                   v-model="user.password_confirm">
                  <label>Nhập lại mật khẩu</label>
                  <small v-if="validate.password_confirm.lengthError">Mật khẩu nhập lại không được để trống<br> </small>
                  <small v-if="validate.password_confirm.invalidError">Mật khẩu không hợp lệ<br> </small>
                  <small v-if="validate.password_confirm.matchError">Mật khẩu không khớp<br> </small>
              </div>
              <div class="alert alert-success w-50 m-1" role="alert" align="left">
                Login Successfully
              </div>
              <div class="form-check-inline check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input" value="Ok" name="accept" id="accept" checked="checked"> Chấp nhận <a href="/dieu-khoan">Điều khoản sử dụng</a>
                </label>
              </div>
              <div id="notify" class="text-danger form-group">
                  
              </div>
              <div class="form-group">
                <button class="btn btn-success font-weight-bold form-control" type="submit" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                      <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                    </svg> ĐĂNG NHẬP
                  </button>
                 
              </div>
            </form>
        </div>
      </div>
       </div>
</template>
<style scoped>
.check{
    float: left;
}
small{
    color : red;
    float: left;
    }
</style>
<script>
import axios from 'axios';
export default{
    name: 'LoginPage',
    data(){
        return{
            user :{
                username : '',
                password : '',
                password_confirm : ''
            },validate :{
                username : {
                    lengthError : false,
                    invalidError : false,
                    existError : false,
                    maxLength : 0
                },
                password : {
                    lengthError : false,
                    invalidError : false
                },
                password_confirm : {
                    lengthError : false,
                    invalidError : false,
                    matchError : false
                },

            }
        }
    },methods : {
        createUser(){
            this.validate.username.lengthError = false;
            this.validate.username.invalidError = false;
            this.validate.username.existError = false;
            this.validate.password.maxLength = false;
            this.validate.password.lengthError = false;
            this.validate.password.invalidError = false;
            this.validate.password_confirm.lengthError = false;
            this.validate.password_confirm.invalidError = false;
            this.validate.password_confirm.matchError = false;

            this.validate.username.lengthError = this.user.username.length == 0;
            this.validate.username.invalidError = !this.validate.username.lengthError && !this.user.username.match(/^[a-zA-Z0-9]+$/);
            this.validate.username.maxLength = this.user.username.length > 20;
            axios.get("/account/find/"+this.user.username).then(res=>{
                if(res.data != null){
                    this.validate.username.existError = true;
                }
            });
            this.validate.password.lengthError = this.user.password.length == 0;
            this.validate.password.invalidError = !this.validate.password.lengthError && !this.user.password.match(/^[a-zA-Z0-9]+$/);
            this.validate.password_confirm.lengthError = this.user.password_confirm.length == 0;
            this.validate.password_confirm.invalidError = !this.validate.password_confirm.lengthError && !this.user.password_confirm.match(/^[a-zA-Z0-9]+$/);
            this.validate.password_confirm.matchError = this.user.password != this.user.password_confirm;
            if(this.validate.username.lengthError || this.validate.username.invalidError || this.validate.username.existError || this.validate.username.maxLength || this.validate.password.lengthError || this.validate.password.invalidError || this.validate.password_confirm.lengthError || this.validate.password_confirm.invalidError || this.validate.password_confirm.matchError){
                return;
            }
            axios.post('/account/save',this.user)
            .then(res => {
                res;
                this.$router.push('/login');
            })
            .catch(err => {
                console.log(err);
            })
        },
    }
}
</script>