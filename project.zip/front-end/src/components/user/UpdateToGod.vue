<template>
    <div class="container">
       <div class="row">
        <div class="col-2"></div>
        <div class="col-6">
            <div class="row">
                <div class="alert alert-success" role="alert">
                    <h6><b>
                        <p>Lưu ý : nạp trên 20k sẽ trở thành thành viên GOD</p>
                        <p>Thỏi vàng sẽ được cộng vào tài khoản của bạn sau ít phút, vui lòng chờ</p>
                    </b></h6>
                </div>
            </div>
            <div class="row h5">
              <b class="text-danger">NẠP THẺ</b>
            </div>
            <form @submit.prevent="updateToGod">
                <div class="form-floating mb-3">
                    <select class="form-select form-select-sm"  @change="showPrice=true;getPriceByName($event)">
                        <option selected disabled>Vui lòng chọn loại thẻ</option>
                        <option v-for="item in type" :value="item" :key="item" @change="item">{{item}}</option>
                    </select>
                    <label for="type">Loại thẻ</label>
                </div>
                <div class="form-floating mb-3" v-if="showPrice">
                    <select class="form-select form-select-sm" v-model="cardData.cardDetail.id">
                        <option selected disabled>Vui lòng chọn mệnh giá</option>
                        <option v-for="item in price " :value="item.id" :key="item.id">{{formatPrice(Number.parseInt(item.price))}} - {{item.thoiVang}} thỏi vàng </option>
                    </select>
                    <label for="type">Mệnh giá</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" id="serial" placeholder="Serial" v-model="cardData.seri">
                    <label for="serial">Seri thẻ</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" id="pin" placeholder="mã thẻ" v-model="cardData.code">
                    <label for="pin">Mã thẻ</label>
                </div>
                <button class="btn btn-success">Nạp thẻ</button>
            </form>
        </div>
        <div class="col-4">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Mệnh giá</th>
                        <th scope="col">Thỏi vàng nhận</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in price" :key="item.id">
                        <td class="table-danger">{{formatPrice(Number.parseInt(item.price))}}</td>
                        <td class="table-success">{{item.thoiVang}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
       </div>
    </div>
</template>
<script>
import axios from 'axios';
export default{
    name : 'UpdateToGod',
    data() {
        return {
            token : localStorage.getItem('token'),
            type : [],
            price : [],
            cardData : {
                cardDetail : {
                    id : 0
                },
                seri : '',
                code : ''
            },showPrice : false,
        }
    },
    created() {
        this.loadData();
    },
    methods : {
        loadData(){
            axios.get('/card/getDistinctName').then(res => {
                this.type= res.data;
            }).catch(err => {
                console.log(err);
            })
        },
        updateToGod(){
            console.log(this.cardData);
            axios.post('/recharge-card/save/'+ this.token , this.cardData ).then(res => {
                alert("Hệ thống đã nhận được thông tin thẻ của bạn, nạp thẻ thành công sẽ được cộng thêm thỏi vàng vào tài khoản của bạn");
               this.$router.push('/account/profile');
                res;
            }).catch(err => {
                err;
                alert("Nạp thẻ thất bại");
            })
        },getPriceByName(event){
            var name = event.target.value;
            console.log(name);
            axios.get("/card-detail/get/card/"+ name).then(res => {
                this.price = res.data;
                console.log(this.price);
            }).catch(err => {
                err;
            })
        },formatPrice(value) {
            let val = (value/1).toFixed(2).replace('.',',')
            return (val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")).substring(0,val.indexOf(",")+1);
        }
    }
}
</script>
<style>
</style>