<template>
    <div class="container">
        <header>
            <marquee behavior="" direction="">
                <img width="12" src="../../assets/images/12.png" alt="...">
                <small class="text-danger">
                    Dành cho người chơi trên 12 tuổi. Chơi quá 180 phút mỗi ngày sẽ hại sức khỏe.
                </small>
            </marquee>
            <div class="row bg pb-3 pt-2 rounded-top" >
                <div class="col">
                  <div class="text-center mb-2">
                    <a href="/">
                        <img width="100%" src="../../assets/images/bia.jpg">
                    </a>
                  </div>
                  <div class="text-center pt-2">
                    <a href="https://www.mediafire.com/file/94s8d9p92i5dwp3/Ngọc+Rồng+GOD.apk/file" class="btn btn-danger text-light btn-sm font-weight-bold border">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
                            <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                            <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
                          </svg>
                        Android
                    </a>
                    <a href="#" class="btn btn-success btn-sm font-weight-bold border btn-danger text-light">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
                            <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                            <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
                          </svg> Pc
                        </a>
                  </div>
                </div>
              </div>
              <hr>
              <slot name="button-header"></slot>
        </header>
    </div>
</template>
<style>
    .container{
        background-color: #e7bcac;
    }
</style>
<script>
export default{
    name: 'HeaderComponent'
}
</script>