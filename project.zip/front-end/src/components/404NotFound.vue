<template>
    
        <h1 class="display-1 fw-bold text-white">404<br>
            <h2>Not found - Trang không tồn tại</h2>
        </h1>      
</template>
<script>
export default {
    name: "404Notfound",  
}
</script>
