import axios from 'axios';
import { createRouter, createWebHistory } from 'vue-router'
const routes = [
      {
          path: '/',
          name: 'HomePage',
          component: () => import('../components/user/ForumComponent.vue')
      },
      {
          path: '/login',
          name: 'Login',
          component: () => import('../views/LoginPage.vue')
      },
      {
        path : '/home',
        name : 'Home',
        component : () => import('../components/user/ForumComponent.vue'),
      }
      ,
      {
        path: '/register',
        name: 'Register',
        component: () => import('../components/user/CreateAccount.vue')
      },
      {
        path: '/change-password',
        name: 'changepassword',
        component: () => import('../components/user/ChangePassword.vue')
      },
      {
        path: '/forum-page',
        name: 'forum',
        component: () => import('../components/user/ForumComponent.vue')
      },
      {
        path : '/account/update/god',
        name : 'updateGod',
        component : () => import('../components/user/UpdateToGod.vue')
      },
      {
        path : '/account/profile',
        name : 'profile',
        component : () => import('../components/user/ProfileUser.vue')
      },
      {
        path :  '/:catchAll(.*)',
        name : 'notfound',
        component : () => import('../components/404NotFound.vue')
      },
      {
        path : '/admin/user-manager',
        name : 'admin',
        component : () => import('../components/admin/UserManager.vue')
      },
      {
        path : '/admin/card-manager',
        name : 'card',
        component : () => import('../components/admin/CardApproved.vue')
      }
]

const router = createRouter({
  history: createWebHistory(),
  routes : routes
});
router.beforeEach((to, from, next) => {
  const publicPages = ['/','/login','/home','/register','/forum-page'];
  const authRequired = !publicPages.includes(to.path);
  const adminPages = ['/admin/user-manager','/admin/card-manager'];
  const adminRequired = adminPages.includes(to.path);
  const loggedIn = localStorage.getItem('user');
  if (authRequired && !loggedIn) {
    return next('/login');
  }
  else if(adminRequired && loggedIn){
    var token = localStorage.getItem('token');
    axios.get("/token/find/" + token).then(res => {
      if(!res.data.data.account.isAdmin)
        next('/:catchAll(.*)');
      else
       next();
    })
  }
  else next();
});

export default router
