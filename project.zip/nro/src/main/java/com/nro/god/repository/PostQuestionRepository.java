package com.nro.god.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface PostQuestionRepository extends org.springframework.data.jpa.repository.JpaRepository<com.nro.god.model.PostQuestion, java.lang.Long> {

}
