package com.nro.god;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NroGodApplication {

	public static void main(String[] args) {
		SpringApplication.run(NroGodApplication.class, args);
	}

}
