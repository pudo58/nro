package com.nro.god;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NroGodApplicationTests {

	@Test
	void contextLoads() {
	}

}
